# GST white-theme and layout audit — v98.85

## Screenshot findings
- GST amount panel rendered dark while the page shell was light.
- GST rate panel rendered dark under the global dark-theme selector.
- Shared keypad dock background was dark.
- The amount entry still showed an inset blue border/outline.
- GST Rate input was visually compressed/hidden beside the quick-rate pills.
- Same State / Different State controls were partially obscured by the dock.

## Changes
- Force a light surface only for the GST screen and its active keypad; other app screens continue to honor the global theme.
- Remove borders, outlines, inset shadows and decorative card frames from GST entry fields.
- Rebuild the amount/rate field geometry with a compact 64px icon column, visible left-aligned entry and right-side quick rates.
- Compact the amount/mode/rate/place rows and enable vertical scrolling with dock-aware bottom padding.
- Keep the 4x4 shared keypad geometry and existing calculation/event handlers unchanged.
- Bump release identity to `1.98.99-v98.85` / Android versionCode `1099105`; synchronize workflow copies and cache namespace.

## Validation scope
Automated source tests and bundle consistency checks are run for this archive. A real Android device screenshot/touch test and remote GitHub Actions execution are not implied by local test results.
- Added the missing `Add rate` placeholder metadata to the GST rate input; this is why the rate entry looked blank in the latest capture.
