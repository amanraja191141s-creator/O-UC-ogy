import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync('index.html', 'utf8');
const js = fs.readFileSync('assets/js/app.js', 'utf8');
const css = fs.readFileSync('assets/css/tool-reference-ui.css', 'utf8');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const workflow = fs.readFileSync('Android-Workflow-v98.82.yml', 'utf8');

test('GST inclusive and exclusive modes distinguish taxable amount from gross amount', () => {
  assert.match(html, /id="tax-base-row"/);
  assert.match(html, /id="tax-base"/);
  assert.match(html, /Gross Amount \(incl\. GST\)/);
  assert.match(js, /taxable = orig;[\s\S]*tax = taxable \* rate \/ 100;[\s\S]*gross = taxable \+ tax;/);
  assert.match(js, /gross = orig;[\s\S]*tax = rate === 0 \? 0 : gross \* rate \/ \(100 \+ rate\);[\s\S]*taxable = gross - tax;/);
  assert.match(js, /setElementText\('tax-base',[\s\S]*setElementText\('tax-total'/);
});

test('GST rate validation matches the recording: rate must be below 40 percent', () => {
  assert.match(js, /rate < 40/);
  assert.match(js, /Number\(nextValue\) >= 40/);
  assert.match(js, /GST rate must be less than 40%/);
});

test('GST clear and backspace restore an actually empty editable field', () => {
  assert.match(js, /val = isGstFieldTarget \? '' : '0'/);
  assert.match(js, /if \(caret > 0\) val = val\.slice\(0, caret - 1\) \+ val\.slice\(caret\)/);
  assert.match(js, /finalVal = val \? val \+ '%' : ''/);
  assert.match(js, /finalVal = val \? formatEditableToolNumber\(val\) : ''/);
});

test('shared keypad preserves the 4x4 geometry and tall equals key responsively', () => {
  assert.match(html, /data-tool-key="7"[\s\S]*data-tool-key="EQUAL"[\s\S]*data-tool-key="\."/);
  assert.match(css, /--tool-keypad-height: min\(42dvh, 360px\)/);
  assert.match(css, /grid-template-columns: repeat\(4, minmax\(0, 1fr\)\)/);
  assert.match(css, /grid-template-rows: repeat\(4, minmax\(0, 1fr\)\)/);
  assert.match(css, /grid-row: 3 \/ span 2/);
  assert.match(css, /orientation: landscape/);
});

test('release identity and workflow are aligned to v98.83', () => {
  assert.equal(pkg.version, '1.98.99-v98.85');
  assert.equal(pkg.androidVersionCode, 1099105);
  assert.match(workflow, /1\.98\.99-v98\.85/);
  assert.match(workflow, /1099105/);
});

test('GST examples from the recording produce rounded expected values', () => {
  const gross = 5956;
  const rate = 9;
  const inclusiveTax = gross * rate / (100 + rate);
  const inclusiveTaxable = gross - inclusiveTax;
  assert.equal(inclusiveTax.toFixed(2), '491.78');
  assert.equal(inclusiveTaxable.toFixed(2), '5464.22');
  assert.equal(gross.toFixed(2), '5956.00');
  const exclusiveTax = gross * rate / 100;
  assert.equal(exclusiveTax.toFixed(2), '536.04');
  assert.equal((gross + exclusiveTax).toFixed(2), '6492.04');
});

test('GST equals cannot commit or dismiss keypad while amount or rate is missing', () => {
  const branch = js.slice(js.indexOf("if (key === 'EQUAL')"), js.indexOf("} else if (key === 'CLR')"));
  assert.match(branch, /if \(STATE\.currentScreen === 'salestax'\)/);
  assert.match(branch, /if \(!amountRaw\) \{ showToast\('Enter amount'\); return; \}/);
  assert.match(branch, /if \(!rateRaw\) \{ showToast\('Enter GST rate'\); return; \}/);
  assert.ok(branch.indexOf("if (!rateRaw)") < branch.indexOf("const activeToolScreen"));
});

test('standard expression starts at an empty expression row with a separate live-preview row', () => {
  assert.match(html, /id="calc-expr"[^>]*placeholder="0"/);
  assert.match(html, /id="calc-val"/);
  assert.ok(js.includes("calcExpr: ''"));
  assert.ok(js.includes('calcCursor: 0'));
  assert.ok(js.includes('calcSelectionStart: 0'));
  assert.ok(js.includes('if (STATE.calcExpr && STATE.liveCalc)'));
});

test('first Backspace after equals restores the exact original expression and caret', () => {
  assert.ok(js.includes('function restoreCalcExpressionFromResult()'));
  assert.ok(js.includes('STATE.calcExpr = expression;'));
  assert.ok(js.includes('STATE.isResultMode = false;'));
  assert.ok(js.includes('function deleteCalcBackward()'));
  assert.ok(js.includes('restoreCalcExpressionFromResult();'));
  assert.ok(js.includes('saveCalcResultExpression(STATE.calcExpr'));
});
