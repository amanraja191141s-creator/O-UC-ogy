# SA Calculator v98.73 — Unified Loan-reference cards and Currency interaction

- Release identity: `1.98.87-v98.73`, Android versionCode `1098400`, service-worker cache `v9873`.
- Unified input-card geometry to the Loan reference: 88px minimum height (82px on narrow screens), 22px radius, 2px border, 12px padding, 50px icon tile, 10px vertical rhythm.
- Currency From/To cards now use the same card geometry with searchable currency selection, live amount conversion, 10-decimal keypad input, readonly converted output, and currency swap on the tall coral keypad key.
- Currency/unit pickers dismiss the numeric keypad while the option dialog is open.
- Source CSS/JS, package identity, PWA manifest, service-worker cache and Android workflow synchronized.
- Device-level pixel comparison and APK build must still be completed by GitHub Actions/on-device validation.
